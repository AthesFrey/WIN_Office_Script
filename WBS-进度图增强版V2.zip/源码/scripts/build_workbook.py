"""Add the milestone sheet without round-tripping legacy Excel controls/styles."""
from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from lxml import etree as ET

from vba_project import rebuild_vba

ROOT = Path(__file__).resolve().parents[1]
NS = {
    "s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}
EXAMPLES = [("首批样品\n加工", dt.date(2026, 8, 20)), ("外观/尺寸\n检查", dt.date(2026, 8, 22)),
            ("探针电测\n验证", dt.date(2026, 8, 25)), ("打线验证", dt.date(2026, 8, 28)),
            ("三批稳定性\n验证", dt.date(2026, 9, 5)), ("量产放行", dt.date(2026, 9, 10))]


def q(prefix, name):
    return f"{{{NS[prefix]}}}{name}"


def sub(parent, prefix, tag, **attrs):
    return ET.SubElement(parent, q(prefix, tag), {k: str(v) for k, v in attrs.items()})


def xml(root):
    return ET.tostring(root, encoding="utf-8", xml_declaration=True, standalone=True)


def emu(points):
    return str(round(points * 12700))


def transform(parent, x, y, width, height):
    xf = sub(parent, "a", "xfrm")
    sub(xf, "a", "off", x=emu(x), y=emu(y))
    sub(xf, "a", "ext", cx=emu(width), cy=emu(height))
    return xf


def text_body(parent, text, bold=False, color="000000", size=1000, center=True):
    body = sub(parent, "xdr", "txBody")
    sub(body, "a", "bodyPr", wrap="none", lIns=0, rIns=0, tIns=0, bIns=0, anchor="t")
    sub(body, "a", "lstStyle")
    for line in text.split("\n"):
        p = sub(body, "a", "p")
        sub(p, "a", "pPr", algn="ctr" if center else "l")
        run = sub(p, "a", "r")
        props = sub(run, "a", "rPr", lang="zh-CN", sz=size, b=int(bold))
        sub(sub(props, "a", "solidFill"), "a", "srgbClr", val=color)
        sub(props, "a", "latin", typeface="Microsoft YaHei")
        sub(props, "a", "ea", typeface="Microsoft YaHei")
        sub(run, "a", "t").text = line
        sub(p, "a", "endParaRPr", lang="zh-CN", sz=size)


def shape(parent, idx, name, x, y, width, height, geometry="rect", color=None,
          text=None, bold=False, macro=None, text_color="000000"):
    attrs = {"macro": "[0]!ProgressChart." + macro} if macro else {}
    sp = sub(parent, "xdr", "sp", **attrs)
    nv = sub(sp, "xdr", "nvSpPr")
    sub(nv, "xdr", "cNvPr", id=idx, name=name)
    sub(nv, "xdr", "cNvSpPr", **({"txBox": "1"} if text is not None and color is None else {}))
    props = sub(sp, "xdr", "spPr")
    transform(props, x, y, width, height)
    geom = sub(props, "a", "prstGeom", prst=geometry)
    values = sub(geom, "a", "avLst")
    if geometry == "rightArrow":
        sub(values, "a", "gd", name="adj1", fmla="val 55000")
        sub(values, "a", "gd", name="adj2", fmla="val 60000")
    if color:
        sub(sub(props, "a", "solidFill"), "a", "srgbClr", val=color)
    else:
        sub(props, "a", "noFill")
    sub(sub(props, "a", "ln"), "a", "noFill")
    if text is not None:
        text_body(sp, text, bold=bold, color=text_color)
        if color:
            body_pr = sp.find("xdr:txBody/a:bodyPr", NS)
            body_pr.set("anchor", "ctr")
    return sp


def anchor(parent, x, y, width, height):
    a = sub(parent, "xdr", "absoluteAnchor")
    sub(a, "xdr", "pos", x=emu(x), y=emu(y))
    sub(a, "xdr", "ext", cx=emu(width), cy=emu(height))
    return a


def button(parent, idx, label, x, y, width, macro, color="2563EB"):
    a = anchor(parent, x, y, width, 25)
    shape(a, idx, "PG_Button_" + macro, x, y, width, 25, geometry="roundRect",
          color=color, text=label, bold=True, macro=macro, text_color="FFFFFF")
    sub(a, "xdr", "clientData", fPrintsWithSheet="0")


def progress_drawing():
    drawing = ET.Element(q("xdr", "wsDr"), nsmap={"xdr": NS["xdr"], "a": NS["a"]})
    button(drawing, 2, "生成 / 刷新进度图", 25, 108, 171, "GenerateProgressChart")
    button(drawing, 3, "复制进度图", 208, 108, 114, "CopyProgressChart", "0F766E")
    # H3 matches the worksheet layout; all coordinates are points.
    x, y, width, height = 628.5, 50, 690, 126
    a = anchor(drawing, x, y, width, height)
    group = sub(a, "xdr", "grpSp")
    nv = sub(group, "xdr", "nvGrpSpPr")
    sub(nv, "xdr", "cNvPr", id=10, name="WBS_ProgressChart", descr="进度图样例：按日期排序、等间距排列，共 6 个节点。")
    sub(nv, "xdr", "cNvGrpSpPr")
    xf = transform(sub(group, "xdr", "grpSpPr"), x, y, width, height)
    sub(xf, "a", "chOff", x=0, y=0)
    sub(xf, "a", "chExt", cx=emu(width), cy=emu(height))
    shape(group, 11, "PG_Background", 0, 0, width, height, color="FFFFFF")
    shape(group, 12, "PG_Axis", 8, 56, width - 16, 12, geometry="rightArrow", color="DC0000")
    gap = (width - 44) / 6
    for i, (label, date) in enumerate(EXAMPLES):
        center = 22 + gap * (i + .5)
        shape(group, 13 + i * 3, f"PG_Marker_{i}", center - 10, 39, 20, 34, geometry="triangle", color="F2A000")
        shape(group, 14 + i * 3, f"PG_Date_{i}", center - (gap - 8) / 2, 13, gap - 8, 21, text=f"{date.month}/{date.day}")
        shape(group, 15 + i * 3, f"PG_Label_{i}", center - (gap - 8) / 2, 80, gap - 8, 36, text=label, bold=True)
    sub(a, "xdr", "clientData")
    return drawing


def add_styles(styles):
    fonts = styles.find("s:fonts", NS)
    fills = styles.find("s:fills", NS)
    xfs = styles.find("s:cellXfs", NS)

    def font(size, bold=False, color="172033"):
        idx = len(fonts)
        f = sub(fonts, "s", "font")
        if bold:
            sub(f, "s", "b")
        sub(f, "s", "sz", val=size)
        sub(f, "s", "color", rgb="FF" + color)
        sub(f, "s", "name", val="Microsoft YaHei")
        sub(f, "s", "charset", val=134)
        return idx

    def fill(color):
        idx = len(fills)
        pf = sub(sub(fills, "s", "fill"), "s", "patternFill", patternType="solid")
        sub(pf, "s", "fgColor", rgb="FF" + color)
        sub(pf, "s", "bgColor", indexed=64)
        return idx

    def style(font_id, fill_id=0, num=0, wrap=False, align="left"):
        idx = len(xfs)
        xf = sub(xfs, "s", "xf", numFmtId=num, fontId=font_id, fillId=fill_id, borderId=0, xfId=0,
                 applyFont=1, applyFill=1, applyAlignment=1, applyNumberFormat=1)
        sub(xf, "s", "alignment", horizontal=align, vertical="center", wrapText=int(wrap))
        return idx

    regular, title, light, header = font(10), font(20, True), font(10, color="64748B"), font(10, True, "FFFFFF")
    date_id = 181
    fmts = styles.find("s:numFmts", NS)
    date_id = max(date_id, max(int(x.get("numFmtId")) for x in fmts) + 1)
    sub(fmts, "s", "numFmt", numFmtId=date_id, formatCode="yyyy/m/d")
    ids = {"regular": style(regular), "title": style(title), "muted": style(light, wrap=True),
           "header": style(header, fill("334155"), wrap=True, align="center"),
           "input": style(regular, fill("EFF6FF"), wrap=True),
           "center": style(regular, fill("EFF6FF"), align="center"),
           "date": style(regular, fill("EFF6FF"), num=date_id),
           "status": style(font(10, color="0F766E"), fill("F0FDFA"), wrap=True)}
    for node in [fonts, fills, xfs, fmts]:
        node.set("count", str(len(node)))
    return ids


def progress_sheet(ids):
    ws = ET.Element(q("s", "worksheet"), nsmap={None: NS["s"], "r": NS["r"]})
    sub(sub(ws, "s", "sheetPr", codeName="Sheet4"), "s", "tabColor", rgb="FFF2A000")
    sub(ws, "s", "dimension", ref="A1:T213")
    view = sub(sub(ws, "s", "sheetViews"), "s", "sheetView", showGridLines=0, tabSelected=1, zoomScale=80, workbookViewId=0)
    sub(view, "s", "pane", ySplit=13, topLeftCell="A14", activePane="bottomLeft", state="frozen")
    sub(view, "s", "selection", pane="bottomLeft", activeCell="D14", sqref="D14")
    sub(ws, "s", "sheetFormatPr", defaultRowHeight=20)
    cols = sub(ws, "s", "cols")
    for i, width in enumerate([3.5, 7, 11, 27, 17, 43, 4], 1):
        sub(cols, "s", "col", min=i, max=i, width=width, customWidth=1)
    sub(cols, "s", "col", min=8, max=30, width=12, customWidth=1)
    data = sub(ws, "s", "sheetData")
    rows = {}

    def cell(row, col, value=None, style="regular"):
        if row not in rows:
            rows[row] = ET.Element(q("s", "row"), r=str(row), ht=str(32 if 14 <= row <= 19 else 20), customHeight="1")
        node = sub(rows[row], "s", "c", r=f"{col}{row}", s=ids[style])
        if isinstance(value, dt.date):
            sub(node, "s", "v").text = str((value - dt.date(1899, 12, 30)).days)
        elif isinstance(value, (int, float)):
            sub(node, "s", "v").text = str(value)
        elif value is not None:
            node.set("t", "inlineStr")
            t = sub(sub(node, "s", "is"), "s", "t")
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            t.text = value

    cell(2, "B", "里程碑进度图", "title")
    rows[2].set("ht", "30")
    cell(3, "B", "日期在上 · 节点在下 · 按日期排序 · 等间距排列", "muted")
    cell(4, "B", "在下表填写节点和日期，或从 WBS 选中任务后导入。", "muted")
    cell(8, "B", "WBS 导入：到 WBS 页选择任务单元格（可按 Ctrl 多选），点击“选中任务加入进度图”。", "muted")
    rows[8].set("ht", "32")
    cell(9, "B", "只生成“显示 = 是”的节点。日期请含年份；名称支持 Alt+Enter 换行。右侧是附图示例。", "muted")
    rows[9].set("ht", "32")
    cell(10, "B", "示例已就绪：可直接修改下方 6 个节点，再点击生成。", "status")
    rows[10].set("ht", "30")
    cell(11, "B", "导入前请删除示例内容，或把示例的“显示”改为“否”。", "muted")
    cell(12, "B", "导入的名称与计划结束日期随 WBS 单元格联动；每次修改后请重新生成。", "muted")
    for col, name in zip("BCDEF", ["显示", "WBS 行号", "节点名称", "节点日期", "备注 / 来源"]):
        cell(13, col, name, "header")
    rows[13].set("ht", "28")
    for r in range(14, 214):
        value = EXAMPLES[r - 14] if r < 20 else None
        cell(r, "B", "是" if value else None, "center")
        cell(r, "C", None, "center")
        cell(r, "D", value[0] if value else None, "input")
        cell(r, "E", value[1] if value else None, "date")
        cell(r, "F", "参考图示例，可修改或删除" if value else None, "input")
    for r in sorted(rows):
        data.append(rows[r])
    merges = sub(ws, "s", "mergeCells", count=9)
    for r in [2, 3, 4, 8, 9, 10, 11, 12]:
        sub(merges, "s", "mergeCell", ref=f"B{r}:F{r}")
    merges.set("count", str(len(merges)))
    dvs = sub(ws, "s", "dataValidations", count=1)
    dv = sub(dvs, "s", "dataValidation", type="list", errorStyle="stop", allowBlank=1,
             showErrorMessage=1, showInputMessage=1, sqref="B14:B213", errorTitle="显示选项", error="请选择“是”或“否”。")
    sub(dv, "s", "formula1").text = '"是,否"'
    sub(ws, "s", "pageMargins", left=.25, right=.25, top=.4, bottom=.4, header=.2, footer=.2)
    sub(ws, "s", "drawing", **{q("r", "id"): "rId1"})
    return ws


def build(source: Path, output: Path):
    with ZipFile(source) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    parts["xl/vbaProject.bin"] = rebuild_vba(parts["xl/vbaProject.bin"], ROOT / "src/ProgressChart.bas")
    styles = ET.fromstring(parts["xl/styles.xml"])
    ids = add_styles(styles)
    parts["xl/styles.xml"] = xml(styles)
    workbook = ET.fromstring(parts["xl/workbook.xml"])
    sheets = workbook.find("s:sheets", NS)
    sub(sheets, "s", "sheet", name="进度图", sheetId=5, **{q("r", "id"): "rId9"})
    workbook.find("s:bookViews/s:workbookView", NS).set("activeTab", "3")
    parts["xl/workbook.xml"] = xml(workbook)
    rels = ET.fromstring(parts["xl/_rels/workbook.xml.rels"])
    sub(rels, "rel", "Relationship", Id="rId9", Type=NS["r"] + "/worksheet", Target="worksheets/sheet4.xml")
    parts["xl/_rels/workbook.xml.rels"] = xml(rels)
    types = ET.fromstring(parts["[Content_Types].xml"])
    for name, content_type in [("/xl/worksheets/sheet4.xml", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"),
                               ("/xl/drawings/drawing2.xml", "application/vnd.openxmlformats-officedocument.drawing+xml")]:
        sub(types, "ct", "Override", PartName=name, ContentType=content_type)
    parts["[Content_Types].xml"] = xml(types)
    wbs = ET.fromstring(parts["xl/worksheets/sheet1.xml"])
    wbs.find("s:sheetViews/s:sheetView", NS).set("tabSelected", "0")
    parts["xl/worksheets/sheet1.xml"] = xml(wbs)
    drawing = ET.fromstring(parts["xl/drawings/drawing1.xml"])
    button(drawing, 2001, "打开进度图", 44, 30, 110, "OpenProgressChart")
    button(drawing, 2002, "选中任务加入进度图", 165, 30, 175, "ImportSelectedMilestones", "0F766E")
    parts["xl/drawings/drawing1.xml"] = xml(drawing)
    parts["xl/drawings/drawing2.xml"] = xml(progress_drawing())
    parts["xl/worksheets/sheet4.xml"] = xml(progress_sheet(ids))
    sheet_rels = ET.Element(q("rel", "Relationships"), nsmap={None: NS["rel"]})
    sub(sheet_rels, "rel", "Relationship", Id="rId1", Type=NS["r"] + "/drawing", Target="../drawings/drawing2.xml")
    parts["xl/worksheets/_rels/sheet4.xml.rels"] = xml(sheet_rels)
    # Adding a worksheet updates document metadata, without changing original data.
    app = ET.fromstring(parts["docProps/app.xml"])
    app_ns = {"p": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
              "vt": "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"}
    titles = app.find("p:TitlesOfParts/vt:vector", app_ns)
    if titles is not None:
        ET.SubElement(titles, "{" + app_ns["vt"] + "}lpstr").text = "进度图"
        titles.set("size", str(len(titles)))
    heading = app.find("p:HeadingPairs/vt:vector", app_ns)
    if heading is not None:
        for value in heading.findall("vt:variant/vt:i4", app_ns):
            value.text = "4"
    parts["docProps/app.xml"] = xml(app)
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "w", ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / "WBS.xlsm")
    parser.add_argument("--output", type=Path, default=ROOT / "dist/WBS-进度图增强版.xlsm")
    args = parser.parse_args()
    print(build(args.source, args.output))
