"""Check VBA syntax using generated ANTLR VBA 7.1 grammar classes.

Generate the parser from grammars-v4/vba/vba7_1 with ANTLR 4.13.2, then pass
its directory via --parser-dir. This does not execute Excel or type-check COM.
"""
import argparse
import sys
from pathlib import Path

from antlr4 import CommonTokenStream, InputStream
from antlr4.error.ErrorListener import ErrorListener


def check(source: Path, parser_dir: Path):
    sys.path.insert(0, str(parser_dir))
    from vbaLexer import vbaLexer
    from vbaParser import vbaParser

    class Errors(ErrorListener):
        def __init__(self):
            self.messages = []

        def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
            self.messages.append(f"{source}:{line}:{column + 1}: {msg}")

    errors = Errors()
    lexer = vbaLexer(InputStream(source.read_text(encoding="utf-8")))
    lexer.removeErrorListeners()
    lexer.addErrorListener(errors)
    parser = vbaParser(CommonTokenStream(lexer))
    parser.removeErrorListeners()
    parser.addErrorListener(errors)
    parser.startRule()
    if errors.messages:
        raise SystemExit("\n".join(errors.messages))
    print(f"{source.name}: VBA 7.1 syntax passed (0 errors)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parser-dir", type=Path, required=True)
    parser.add_argument("source", type=Path, nargs="?", default=Path(__file__).resolve().parents[1] / "src/ProgressChart.bas")
    args = parser.parse_args()
    check(args.source, args.parser_dir)
