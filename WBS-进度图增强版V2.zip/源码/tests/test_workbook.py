"""File-level regression tests. Excel COM smoke tests are kept separately."""
import datetime as dt
import io
import posixpath
import random
import re
import sys
import warnings
from pathlib import Path
from zipfile import ZipFile

import olefile
import openpyxl
import pytest
from lxml import etree as ET
from oletools.olevba import VBA_Parser, VBA_Project, decompress_stream

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from build_workbook import EXAMPLES, NS, build
from vba_project import END, FREE, cfb_write, compress_vba


@pytest.fixture(scope="session")
def artifact(tmp_path_factory):
    return build(ROOT / "WBS.xlsm", tmp_path_factory.mktemp("release") / "WBS.xlsm")


@pytest.fixture(scope="session")
def parts(artifact):
    with ZipFile(artifact) as z:
        assert z.testzip() is None
        return {n: z.read(n) for n in z.namelist()}


def tree_signature(node):
    return node.tag, dict(node.attrib), node.text, [tree_signature(c) for c in node]


def test_original_cells_and_formulas_unchanged(parts):
    with ZipFile(ROOT / "WBS.xlsm") as original:
        before = ET.fromstring(original.read("xl/worksheets/sheet1.xml"))
        after = ET.fromstring(parts["xl/worksheets/sheet1.xml"])
        before.find("s:sheetViews/s:sheetView", NS).set("tabSelected", "0")
        assert tree_signature(before) == tree_signature(after)
        for name in ["xl/worksheets/sheet2.xml", "xl/worksheets/sheet3.xml", "xl/sharedStrings.xml",
                     "xl/drawings/vmlDrawing1.vml", "xl/ctrlProps/ctrlProp1.xml", "xl/calcChain.xml",
                     "xl/worksheets/_rels/sheet1.xml.rels"]:
            assert original.read(name) == parts[name], name


def test_all_package_relationship_targets_exist(parts):
    for name, data in parts.items():
        if name.endswith(".xml") or name.endswith(".rels"):
            ET.fromstring(data)
        if not name.endswith(".rels"):
            continue
        root = ET.fromstring(data)
        ids = [r.get("Id") for r in root]
        assert len(ids) == len(set(ids))
        parent = posixpath.dirname(posixpath.dirname(name))
        for rel in root:
            if rel.get("TargetMode") == "External":
                continue
            target = rel.get("Target")
            full = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(parent, target))
            assert full in parts, (name, target)


def test_preserve_old_styles_and_gantt_control(parts):
    with ZipFile(ROOT / "WBS.xlsm") as z:
        before = ET.fromstring(z.read("xl/styles.xml"))
        after = ET.fromstring(parts["xl/styles.xml"])
        for group in before:
            current = after.find(group.tag)
            assert current is not None
            for i, element in enumerate(group):
                assert tree_signature(element) == tree_signature(current[i])
        original_drawing = ET.fromstring(z.read("xl/drawings/drawing1.xml"))
        new_drawing = ET.fromstring(parts["xl/drawings/drawing1.xml"])
        assert tree_signature(original_drawing[0]) == tree_signature(new_drawing[0])


def test_original_vba_source_preserved_and_new_module_embedded(artifact, parts):
    def sources(path):
        parser = VBA_Parser(str(path))
        try:
            return {name: code for _, _, name, code in parser.extract_macros()}
        finally:
            parser.close()
    before, after = sources(ROOT / "WBS.xlsm"), sources(artifact)
    for name, code in before.items():
        assert after[name] == code
    assert after["ProgressChart.bas"].replace("\r\n", "\n") == (ROOT / "src/ProgressChart.bas").read_text()
    assert 'Attribute VB_Name = "Sheet4"' in after["Sheet4.cls"]
    ole = olefile.OleFileIO(io.BytesIO(parts["xl/vbaProject.bin"]), raise_defects=olefile.DEFECT_INCORRECT)
    assert not ole.parsing_issues
    assert not any("__SRP" in "/".join(n) for n in ole.listdir())
    project = VBA_Project(ole, "", "PROJECT", "VBA/dir")
    project.parse_project_stream()
    list(project.parse_modules())
    assert len(project.modules) == 8
    for module in project.modules:
        assert module.textoffset == 0
    assert ole.openstream("VBA/_VBA_PROJECT").read() == bytes.fromhex("cc61ffff000000")


def test_buttons_have_real_public_entry_points(parts):
    code = (ROOT / "src/ProgressChart.bas").read_text()
    entry_points = set(re.findall(r"Public Sub (\w+)\(\)", code))
    bindings = []
    for name in ["xl/drawings/drawing1.xml", "xl/drawings/drawing2.xml"]:
        drawing = ET.fromstring(parts[name])
        ids = [n.get("id") for n in drawing.findall(".//xdr:cNvPr", NS)]
        assert len(ids) == len(set(ids))
        for node in drawing.findall(".//xdr:sp", NS):
            macro = node.get("macro")
            if macro:
                assert macro.startswith("[0]!ProgressChart.")
                routine = macro.split(".")[-1]
                assert routine in entry_points
                bindings.append(routine)
    assert set(bindings) == {"OpenProgressChart", "ImportSelectedMilestones", "GenerateProgressChart", "CopyProgressChart"}


def test_example_workbook_loads_and_dates_are_real(artifact):
    with warnings.catch_warnings():
        # Legacy extensions are preserved by our XML edits; openpyxl is read-only here.
        warnings.simplefilter("ignore", UserWarning)
        wb = openpyxl.load_workbook(artifact, keep_vba=True)
    assert wb.sheetnames == ["WBS", "Data", "Resource", "进度图"]
    ws = wb["进度图"]
    assert wb.active == ws
    assert ws.sheet_properties.codeName == "Sheet4"
    assert ws.freeze_panes == "A14"
    for r, (label, date) in enumerate(EXAMPLES, 14):
        assert ws.cell(r, 2).value == "是"
        assert ws.cell(r, 4).value == label
        assert ws.cell(r, 5).value.date() == date
    assert ws.data_validations.dataValidation[0].sqref == "B14:B213"
    assert '"是,否"' == ws.data_validations.dataValidation[0].formula1
    assert len(ws.merged_cells.ranges) == 8
    wb.close()


def test_chart_geometry_and_labels_match_example_data(parts):
    drawing = ET.fromstring(parts["xl/drawings/drawing2.xml"])
    group = drawing.find("xdr:absoluteAnchor/xdr:grpSp", NS)
    assert group.find("xdr:nvGrpSpPr/xdr:cNvPr", NS).get("name") == "WBS_ProgressChart"
    shapes = group.findall("xdr:sp", NS)
    assert len(shapes) == 20
    positions = []
    for i, (label, date) in enumerate(EXAMPLES):
        triangle, datebox, labelbox = shapes[2 + 3 * i:5 + 3 * i]
        assert triangle.find("xdr:spPr/a:prstGeom", NS).get("prst") == "triangle"
        assert triangle.find("xdr:spPr/a:solidFill/a:srgbClr", NS).get("val") == "F2A000"
        assert "".join(datebox.findall(".//a:t", NS)[0].itertext()) == f"{date.month}/{date.day}"
        assert "\n".join(t.text for t in labelbox.findall(".//a:t", NS)) == label
        tpos = triangle.find("xdr:spPr/a:xfrm/a:off", NS)
        tsize = triangle.find("xdr:spPr/a:xfrm/a:ext", NS)
        lpos = labelbox.find("xdr:spPr/a:xfrm/a:off", NS)
        assert int(lpos.get("y")) > int(tpos.get("y")) + int(tsize.get("cy"))
        positions.append(int(tpos.get("x")))
    gaps = [b - a for a, b in zip(positions, positions[1:])]
    assert max(gaps) - min(gaps) <= 1


@pytest.mark.parametrize("data", [b"", b"a", b"abc" * 3000, b" " * 4096, bytes(range(256)) * 40,
                                  random.Random(8).randbytes(5000), random.Random(4).randbytes(8192)])
def test_vba_compression_round_trip(data):
    assert decompress_stream(compress_vba(data)) == data


def test_cfb_small_large_streams_and_red_black_trees():
    streams = {f"VBA/Module{i}": random.Random(i).randbytes(size)
               for i, size in enumerate([0, 1, 63, 64, 65, 511, 512, 4095, 4096, 4097, 12000])}
    streams.update({"PROJECT": b"metadata", "PROJECTwm": b"names", "VBA/模块": b"unicode"})
    data = cfb_write(streams)
    ole = olefile.OleFileIO(io.BytesIO(data), raise_defects=olefile.DEFECT_INCORRECT)
    assert not ole.parsing_issues
    for name, value in streams.items():
        assert ole.openstream(name).read() == value

    def verify(index):
        if index == FREE:
            return 1
        e = ole.direntries[index]
        if e is None:
            e = ole._load_direntry(index)
        left, right = verify(e.sid_left), verify(e.sid_right)
        assert left == right
        if e.color == 0:
            for child in [e.sid_left, e.sid_right]:
                if child != FREE:
                    assert ole.direntries[child].color == 1
        return left + int(e.color == 1)

    verify(ole.root.sid_child)
    for entry in ole.direntries:
        if entry is not None and entry.entry_type == 1:
            verify(entry.sid_child)
