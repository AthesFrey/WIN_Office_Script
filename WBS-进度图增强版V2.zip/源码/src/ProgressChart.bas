Attribute VB_Name = "ProgressChart"
Option Explicit

Private Const PG_SHEET As String = "进度图"
Private Const PG_FIRST As Long = 14
Private Const PG_LAST As Long = 213
Private Const PG_LIMIT As Long = 60
Private Const PG_GROUP As String = "WBS_ProgressChart"
Private Const PG_TEMP As String = "WBS_PG_TMP_"

' B: include, C: WBS row (optional), D: name, E: date, F: source description.
' Source rows are stored for reference only; imported name/date cells use formulas.
Public Sub OpenProgressChart()
    On Error GoTo Failed
    ThisWorkbook.Worksheets(PG_SHEET).Activate
    Exit Sub
Failed:
    MsgBox "未找到进度图工作表，请使用包含进度图功能的完整工作簿。", vbExclamation
End Sub

Public Sub ImportSelectedMilestones()
    Dim source As Worksheet, target As Worksheet, picked As Range, part As Range
    Dim rowNumbers() As Long, count As Long, r As Long, i As Long, j As Long
    Dim firstRow As Long, lastRow As Long, swapRow As Long, duplicate As Boolean
    Dim dest As Long, freeRows As Long, oldScreen As Boolean, changed As Boolean
    Dim taskValue As Variant, reason As String
    On Error GoTo Failed
    Set source = ThisWorkbook.Worksheets("WBS")
    Set target = ThisWorkbook.Worksheets(PG_SHEET)
    target.Calculate
    If Not ActiveWorkbook Is ThisWorkbook Then
        MsgBox "请先在本工作簿的 WBS 页选中需要的任务。", vbInformation
        Exit Sub
    End If
    If Not ActiveSheet Is source Then
        MsgBox "请先在 WBS 页选中需要的任务行，再点“选中任务加入进度图”。", vbInformation
        Exit Sub
    End If
    If TypeName(Selection) <> "Range" Then
        MsgBox "请先选中任务单元格或任务行。", vbInformation
        Exit Sub
    End If
    Set picked = Selection
    lastRow = source.Cells(source.Rows.Count, 3).End(xlUp).Row
    If lastRow < 6 Then
        MsgBox "WBS 中还没有任务。", vbInformation
        Exit Sub
    End If
    Set picked = Application.Intersect(picked, source.Rows("6:" & lastRow))
    If picked Is Nothing Then
        MsgBox "请选中第 6 行起的任务。", vbInformation
        Exit Sub
    End If
    ReDim rowNumbers(1 To PG_LAST - PG_FIRST + 1)
    For Each part In picked.Areas
        firstRow = part.Row
        For r = firstRow To firstRow + part.Rows.Count - 1
            taskValue = source.Cells(r, 3).Value
            If Not IsError(taskValue) Then
                If Len(Trim$(CStr(taskValue))) > 0 Then
                    duplicate = False
                    For i = 1 To count
                        If rowNumbers(i) = r Then duplicate = True
                    Next i
                    For i = PG_FIRST To PG_LAST
                        If Not IsError(target.Cells(i, 3).Value) Then
                            If CStr(target.Cells(i, 3).Value) = CStr(r) Then duplicate = True
                        End If
                    Next i
                    If Not duplicate Then
                        count = count + 1
                        If count > UBound(rowNumbers) Then
                            MsgBox "一次最多导入 200 个任务，请缩小选择范围。", vbExclamation
                            Exit Sub
                        End If
                        rowNumbers(count) = r
                    End If
                End If
            End If
        Next r
    Next part
    If count = 0 Then
        MsgBox "所选任务已在进度图中，或选区中没有任务名称。", vbInformation
        Exit Sub
    End If
    For r = PG_FIRST To PG_LAST
        If Application.CountA(target.Range("B" & r & ":F" & r)) = 0 Then freeRows = freeRows + 1
    Next r
    If count > freeRows Then
        MsgBox "进度图输入区剩余 " & freeRows & " 行，无法容纳这次选择。请先清理不用的行。", vbExclamation
        Exit Sub
    End If
    ' Stable source-row order, including selections made with Ctrl.
    For i = 2 To count
        swapRow = rowNumbers(i)
        j = i - 1
        Do While j >= 1
            If rowNumbers(j) <= swapRow Then Exit Do
            rowNumbers(j + 1) = rowNumbers(j)
            j = j - 1
        Loop
        rowNumbers(j + 1) = swapRow
    Next i
    oldScreen = Application.ScreenUpdating
    Application.ScreenUpdating = False
    changed = True
    dest = PG_FIRST
    For i = 1 To count
        Do While Application.CountA(target.Range("B" & dest & ":F" & dest)) > 0
            dest = dest + 1
        Loop
        r = rowNumbers(i)
        target.Cells(dest, 2).Value = "是"
        target.Cells(dest, 3).Formula = "=ROW(WBS!C" & r & ")"
        target.Cells(dest, 4).Formula = "=IF(WBS!C" & r & "="""","""",WBS!C" & r & ")"
        target.Cells(dest, 5).Formula = "=IF(WBS!H" & r & "="""","""",WBS!H" & r & ")"
        target.Cells(dest, 5).NumberFormat = "yyyy/m/d"
        target.Cells(dest, 6).Value = "WBS 计划结束日期（公式联动）"
        dest = dest + 1
    Next i
    target.Activate
    target.Range("B10").Value = "已加入 " & count & " 个任务；检查日期后点击“生成 / 刷新进度图”。"
    Application.ScreenUpdating = oldScreen
    Exit Sub
Failed:
    reason = Err.Description
    If changed Then Application.ScreenUpdating = oldScreen
    MsgBox "导入任务失败：" & reason, vbExclamation
End Sub

Public Sub GenerateProgressChart()
    Dim ws As Worksheet, names() As String, dates() As Date, count As Long
    Dim r As Long, i As Long, j As Long, mark As String, taskName As String
    Dim milestoneDate As Date, swappedDate As Date, swappedName As String
    Dim shapeIndexes() As Variant, shapeCount As Long, shp As Shape, group As Shape
    Dim width As Single, height As Single, gap As Single, left As Single, top As Single
    Dim center As Single, axis As Single, labelWidth As Single, labelHeight As Single
    Dim dateFormat As String, lines As Long, oldScreen As Boolean, changed As Boolean
    Dim reason As String, value As Variant, stage As String, errorNumber As Long
    On Error GoTo Failed
    stage = "读取节点数据"
    Set ws = ThisWorkbook.Worksheets(PG_SHEET)
    ' Recalculate linked cells, including when Excel is in manual calculation mode.
    ThisWorkbook.Worksheets("WBS").Calculate
    ws.Calculate
    ReDim names(1 To PG_LIMIT)
    ReDim dates(1 To PG_LIMIT)
    For r = PG_FIRST To PG_LAST
        value = ws.Cells(r, 2).Value
        If IsError(value) Then
            MsgBox "第 " & r & " 行“显示”包含错误，请改为“是”或“否”。", vbExclamation
            Exit Sub
        End If
        mark = Trim$(CStr(value))
        If mark <> "" And mark <> "否" And mark <> "是" Then
            MsgBox "第 " & r & " 行“显示”只能填写“是”或“否”。", vbExclamation
            Exit Sub
        End If
        If mark = "是" Then
            value = ws.Cells(r, 4).Value
            If IsError(value) Then
                MsgBox "第 " & r & " 行节点名称包含公式错误，请修正。", vbExclamation
                Exit Sub
            End If
            taskName = Trim$(CStr(value))
            If Not IsError(ws.Cells(r, 3).Value) Then
                If Len(CStr(ws.Cells(r, 3).Value)) > 0 Then taskName = ProgressLabel(taskName)
            End If
            If Len(taskName) = 0 Then
                MsgBox "第 " & r & " 行缺少节点名称。", vbExclamation
                Exit Sub
            End If
            If Len(taskName) > 120 Then
                MsgBox "第 " & r & " 行名称过长，请精简到 120 个字符以内。", vbExclamation
                Exit Sub
            End If
            If Not TryProgressDate(ws.Cells(r, 5).Value, milestoneDate) Then
                MsgBox "第 " & r & " 行日期无效。请填写 Excel 日期或 yyyy/m/d 格式（如 2026/8/20）。", vbExclamation
                Exit Sub
            End If
            count = count + 1
            If count > PG_LIMIT Then
                MsgBox "单张进度图最多显示 60 个节点，请将部分节点的“显示”改为“否”。", vbExclamation
                Exit Sub
            End If
            names(count) = taskName
            dates(count) = milestoneDate
        End If
    Next r
    If count = 0 Then
        MsgBox "请至少填写一个节点，并将“显示”设为“是”。原进度图已保留。", vbInformation
        Exit Sub
    End If
    ' Insertion sort keeps input order for milestones on the same date.
    For i = 2 To count
        swappedDate = dates(i)
        swappedName = names(i)
        j = i - 1
        Do While j >= 1
            If dates(j) <= swappedDate Then Exit Do
            dates(j + 1) = dates(j)
            names(j + 1) = names(j)
            j = j - 1
        Loop
        dates(j + 1) = swappedDate
        names(j + 1) = swappedName
    Next i
    dateFormat = "m/d"
    If Year(dates(1)) <> Year(dates(count)) Then dateFormat = "yyyy/m/d"
    width = 690
    If count > 6 Then width = count * 115
    gap = (width - 44) / count
    labelWidth = gap - 8
    labelHeight = 36
    For i = 1 To count
        names(i) = WrapProgressLabel(names(i), 8)
        lines = UBound(Split(names(i), vbLf)) + 1
        If lines * 15 > labelHeight Then labelHeight = lines * 15
    Next i
    height = 90 + labelHeight
    left = ws.Range("H3").Left
    top = ws.Range("H3").Top
    axis = top + 62
    oldScreen = Application.ScreenUpdating
    Application.ScreenUpdating = False
    changed = True
    ' Grouping needs a single active worksheet and no old group in edit mode.
    ThisWorkbook.Activate
    ws.Select Replace:=True
    ws.Range("B14").Select
    DeleteProgressTemps ws
    ReDim shapeIndexes(0 To 1 + 3 * count)
    stage = "绘制图形"
    ' Build a new group first; the existing chart survives invalid input/drawing errors.
    Set shp = ws.Shapes.AddShape(msoShapeRectangle, left, top, width, height)
    RememberProgressShape shp, shapeIndexes, shapeCount
    shp.Fill.ForeColor.RGB = RGB(255, 255, 255)
    shp.Line.Visible = msoFalse
    Set shp = ws.Shapes.AddShape(msoShapeRightArrow, left + 8, axis - 6, width - 16, 12)
    RememberProgressShape shp, shapeIndexes, shapeCount
    shp.Fill.ForeColor.RGB = RGB(220, 0, 0)
    shp.Line.Visible = msoFalse
    shp.Adjustments.Item(1) = 0.55
    shp.Adjustments.Item(2) = 0.6
    For i = 1 To count
        center = left + 22 + gap * (i - 0.5)
        Set shp = ws.Shapes.AddShape(msoShapeIsoscelesTriangle, center - 10, axis - 23, 20, 34)
        RememberProgressShape shp, shapeIndexes, shapeCount
        shp.Fill.ForeColor.RGB = RGB(242, 160, 0)
        shp.Line.Visible = msoFalse
        Set shp = AddProgressText(ws, Format$(dates(i), dateFormat), center - labelWidth / 2, top + 13, labelWidth, 21, False)
        RememberProgressShape shp, shapeIndexes, shapeCount
        Set shp = AddProgressText(ws, names(i), center - labelWidth / 2, axis + 18, labelWidth, labelHeight, True)
        RememberProgressShape shp, shapeIndexes, shapeCount
    Next i
    stage = "组合图形"
    Set group = ws.Shapes.Range(shapeIndexes).Group
    group.Name = PG_TEMP & "GROUP"
    group.Placement = xlFreeFloating
    group.AlternativeText = "进度图：按日期排序、等间距排列，共 " & count & " 个节点。"
    stage = "更新进度图"
    ws.Range("B10").Value = "已生成 " & count & " 个节点；" & Format$(dates(1), "yyyy/m/d") & " - " & Format$(dates(count), "yyyy/m/d")
    ' Commit only after all shapes have been created successfully.
    For i = ws.Shapes.Count To 1 Step -1
        If ws.Shapes(i).Name = PG_GROUP Then ws.Shapes(i).Delete
    Next i
    group.Name = PG_GROUP
    group.Select
    Application.ScreenUpdating = oldScreen
    Exit Sub
Failed:
    reason = Err.Description
    errorNumber = Err.Number
    On Error Resume Next
    If Not ws Is Nothing Then DeleteProgressTemps ws
    If changed Then Application.ScreenUpdating = oldScreen
    On Error GoTo 0
    MsgBox "生成进度图失败（" & stage & "，错误 " & errorNumber & "）：" & reason & vbCrLf & "请检查“进度图”工作表是否受保护；如仍失败，请提供此错误提示。", vbExclamation
End Sub

Public Sub CopyProgressChart()
    Dim ws As Worksheet, group As Shape
    On Error GoTo Failed
    Set ws = ThisWorkbook.Worksheets(PG_SHEET)
    On Error Resume Next
    Set group = ws.Shapes(PG_GROUP)
    On Error GoTo Failed
    If group Is Nothing Then
        MsgBox "请先点击“生成 / 刷新进度图”。", vbInformation
        Exit Sub
    End If
    ws.Activate
    group.CopyPicture Appearance:=xlScreen, Format:=xlPicture
    MsgBox "进度图已复制，可直接粘贴到 Word、PPT 或其他工作表。", vbInformation
    Exit Sub
Failed:
    MsgBox "复制失败：" & Err.Description & vbCrLf & "也可以选中整张进度图后按 Ctrl+C。", vbExclamation
End Sub

Private Sub DeleteProgressTemps(ByVal ws As Worksheet)
    Dim i As Long
    For i = ws.Shapes.Count To 1 Step -1
        If Left$(ws.Shapes(i).Name, Len(PG_TEMP)) = PG_TEMP Then ws.Shapes(i).Delete
    Next i
End Sub

Private Sub RememberProgressShape(ByVal shp As Shape, ByRef indexes() As Variant, ByRef count As Long)
    shp.Name = PG_TEMP & "SHAPE_" & CStr(shp.ID)
    shp.Placement = xlFreeFloating
    ' Shape names also exist inside old groups, including legacy TMP_0, TMP_1, ...
    ' Use top-level worksheet indexes so Excel cannot resolve an old group child.
    ' New shapes are appended; do not reorder/delete any until they are grouped.
    indexes(count) = shp.ZOrderPosition
    count = count + 1
End Sub

Private Function AddProgressText(ByVal ws As Worksheet, ByVal value As String, ByVal left As Single, ByVal top As Single, ByVal width As Single, ByVal height As Single, ByVal bold As Boolean) As Shape
    Dim shp As Shape
    Set shp = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, left, top, width, height)
    shp.Name = PG_TEMP & "SHAPE_" & CStr(shp.ID)
    shp.Fill.Visible = msoFalse
    shp.Line.Visible = msoFalse
    With shp.TextFrame2
        .MarginLeft = 0
        .MarginRight = 0
        .MarginTop = 0
        .MarginBottom = 0
        .WordWrap = msoFalse
        .AutoSize = msoAutoSizeNone
        .VerticalAnchor = msoAnchorTop
        .TextRange.Text = value
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .TextRange.Font.Name = "Microsoft YaHei"
        .TextRange.Font.Size = 10
        .TextRange.Font.Fill.ForeColor.RGB = RGB(0, 0, 0)
        If bold Then .TextRange.Font.Bold = msoTrue
    End With
    Set AddProgressText = shp
End Function

Public Function ProgressLabel(ByVal value As String) As String
    Dim pos As Long, token As String, i As Long, ch As String, numbered As Boolean
    value = Trim$(Replace(value, vbTab, " "))
    pos = InStr(value, " ")
    If pos > 1 Then
        token = Left$(value, pos - 1)
        numbered = True
        For i = 1 To Len(token)
            ch = Mid$(token, i, 1)
            If (ch < "0" Or ch > "9") And ch <> "." Then numbered = False
        Next i
        If Left$(token, 1) = "." Then numbered = False
        If InStr(token, "..") > 0 Then numbered = False
        If numbered Then value = Trim$(Mid$(value, pos + 1))
    End If
    ProgressLabel = value
End Function

Public Function WrapProgressLabel(ByVal value As String, ByVal maxChars As Long) As String
    Dim i As Long, count As Long, ch As String, result As String
    value = Replace(Replace(value, vbCrLf, vbLf), vbCr, vbLf)
    For i = 1 To Len(value)
        ch = Mid$(value, i, 1)
        If ch = vbLf Then
            result = result & vbLf
            count = 0
        Else
            If count >= maxChars Then
                result = result & vbLf
                count = 0
            End If
            result = result & ch
            count = count + 1
        End If
    Next i
    WrapProgressLabel = result
End Function

Public Function TryProgressDate(ByVal value As Variant, ByRef result As Date) As Boolean
    Dim text As String, parts() As String, y As Long, m As Long, d As Long, i As Long
    Dim serial As Double
    On Error GoTo InvalidDate
    If IsError(value) Or IsEmpty(value) Or IsNull(value) Then Exit Function
    If VarType(value) = vbBoolean Then Exit Function
    If VarType(value) = vbDate Then
        result = DateSerial(Year(value), Month(value), Day(value))
    ElseIf IsNumeric(value) And VarType(value) <> vbString Then
        serial = CDbl(value)
        If ThisWorkbook.Date1904 Then
            If serial < 0 Or serial >= 2957004# Then Exit Function
            serial = serial + 1462
        Else
            If serial < 1 Or serial >= 2958466# Then Exit Function
            ' Excel's fictitious 1900/2/29 cannot become a real VBA date.
            If Fix(serial) = 60 Then Exit Function
            If serial < 60 Then serial = serial + 1
        End If
        result = CDate(Fix(serial))
    Else
        text = Trim$(CStr(value))
        text = Replace(Replace(text, "-", "/"), ".", "/")
        parts = Split(text, "/")
        If UBound(parts) <> 2 Then Exit Function
        If Len(parts(0)) <> 4 Or Len(parts(1)) < 1 Or Len(parts(1)) > 2 Or Len(parts(2)) < 1 Or Len(parts(2)) > 2 Then Exit Function
        For i = 1 To Len(text)
            If InStr("0123456789/", Mid$(text, i, 1)) = 0 Then Exit Function
        Next i
        y = CLng(parts(0))
        m = CLng(parts(1))
        d = CLng(parts(2))
        If y < 1900 Or y > 9999 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
        result = DateSerial(y, m, d)
        If Year(result) <> y Or Month(result) <> m Or Day(result) <> d Then Exit Function
    End If
    If Year(result) < 1900 Then Exit Function
    TryProgressDate = True
InvalidDate:
End Function
