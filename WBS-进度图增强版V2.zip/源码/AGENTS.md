# 工程位置与升级约定

- 本工具属于当前 `office` 项目，工程已迁移至 `/srv/proj/office/wbs-gantt-chart`。
- 后续升级、依赖安装、构建和验证均在此目录执行，不使用旧路径 `/srv/proj/wbs-gantt-chart`，不在 `/srv/proj` 下另建并列工程。
- 遵守现有 `pyproject.toml` 和 `uv.lock`，使用 `uv sync --locked` 准备依赖。
- 目录移动后，旧 `.venv` 内的启动脚本可能仍引用原路径；使用前检查，必要时在当前工程内重建虚拟环境。
- 构建命令：`uv run python scripts/build_workbook.py`；回归检查：`uv run pytest -q`。
- 构建产物位于当前工程的 `dist/`；用户交付压缩包放在 `/srv/proj/office/` 内。
- 保留用户现有未提交修改。不得把文件结构或源码检查描述成已经通过桌面版 Excel 实测。
